import './bower_components/jquery-ui/jquery-ui.js?script-loader';
import './bower_components/jqueryui-timepicker-addon/dist/jquery-ui-timepicker-addon.js?script-loader';
import './bower_components/jquery-ui/themes/smoothness/jquery-ui.css';
import './bower_components/jqueryui-timepicker-addon/dist/jquery-ui-timepicker-addon.css';
import './bower_components/jquery-ui-month-picker/src/MonthPicker';
import './bower_components/jquery-ui-month-picker/src/MonthPicker.css';
