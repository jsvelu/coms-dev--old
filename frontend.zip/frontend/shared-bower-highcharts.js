import './bower_components/highcharts-release/highcharts.js?script-loader';
import './bower_components/highcharts-release/highcharts-3d.js?script-loader';
import './bower_components/highcharts-release/modules/exporting.js?script-loader';
