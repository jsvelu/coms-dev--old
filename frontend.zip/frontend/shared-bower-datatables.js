import './bower_components/datatables/media/js/jquery.dataTables.js?script-loader';
import './bower_components/datatables-select/js/dataTables.select.js?script-loader';
import './bower_components/datatables/media/css/jquery.dataTables.css';
