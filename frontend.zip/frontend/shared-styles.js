// This file exists so ExtractTextPlugin works with CommonsChunkPlugin
import "./apps/shared/style.scss";